#include "tank.h"
#include <QPainter>


Tank::Tank()
{

}

Tank::Tank(QPoint pos, QRect size)
    :pos(pos),size(size)
{

}

void Tank::draw(QPainter *painter)
{
    const QImage tank(":/image/t72.png");
    painter->setBrush(tank);
    painter->drawImage(size, tank);
}

QPoint Tank::Move(QPoint move)
{
    pos += move;
}

QPoint Tank::getPos() const
{
    return pos;
}

void Tank::setPos(QPoint newPos)
{
    pos = newPos;
}

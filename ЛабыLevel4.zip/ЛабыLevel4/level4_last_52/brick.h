#ifndef BRICK_H
#define BRICK_H
#include <QPoint>
#include <QRect>

class Brick
{
public:
    Brick();

protected:
    QPoint pos;
    QRect size;
};

#endif // BRICK_H

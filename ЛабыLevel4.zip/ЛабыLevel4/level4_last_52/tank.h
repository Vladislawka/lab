#ifndef TANK_H
#define TANK_H
#include <QPoint>
#include <QRect>
#include <QPainter>

class Tank
{
public:
    Tank();
    Tank(QPoint pos, QRect size);

    void draw(QPainter *painter);
    QPoint Move(QPoint move);


    QPoint getPos() const;
    void setPos(QPoint newPos);

protected:
    QPoint pos;
    QRect size;
};

#endif // TANK_H

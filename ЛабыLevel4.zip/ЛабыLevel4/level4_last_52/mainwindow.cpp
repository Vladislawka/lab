#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QPainter>
#include <QMouseEvent>
#include <QPoint>
#include <QRect>
#include "tank.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    const QImage grass(":/image/grass16x16.GIF");
    const QImage flower(":/image/flower.jpg");
    const QImage brick(":/image/brick-tile-2.png");
    QRect background = contentsRect();
    painter.setBrush(grass);
    painter.drawRect(background);

    if (tank) tank->draw(&painter);

    for (QRect i: flowers) painter.drawImage(i, flower);
    for (QRect i: bricks) painter.drawImage(i, brick);
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (event->modifiers() & Qt::ControlModifier && !tank) {
        tank = new Tank(event->pos(), QRect(event->pos() - tank_size, event->pos() + tank_size));
    }
    else if (event->button() == Qt::LeftButton) { // на кирпич
        bricks.append(QRect(event->pos() - brick_size, event->pos() + brick_size));
    }
    if (event->button() == Qt::RightButton) {// на цветочки
        flowers.append(QRect(event->pos() - flower_size, event->pos() + flower_size));
    }
    repaint();
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_W && tank) {
        tank = new Tank(tank->getPos() + QPoint(0, -V), QRect(tank->getPos() + QPoint(0, -V) - tank_size, tank->getPos() + QPoint(0, -V) + tank_size));
    }
    if (event->key() == Qt::Key_S && tank) {
        tank = new Tank(tank->getPos() + QPoint(0, V), QRect(tank->getPos() + QPoint(0, V) - tank_size, tank->getPos() + QPoint(0, V) + tank_size));
    }
    if (event->key() == Qt::Key_A && tank) {
        tank = new Tank(tank->getPos() + QPoint(-V, 0), QRect(tank->getPos() + QPoint(-V, 0) - tank_size, tank->getPos() + QPoint(-V, 0) + tank_size));
    }
    if (event->key() == Qt::Key_D && tank) {
        tank = new Tank(tank->getPos() + QPoint(V, 0), QRect(tank->getPos() + QPoint(V, 0) - tank_size, tank->getPos() + QPoint(V, 0) + tank_size));
    }
    repaint();
}


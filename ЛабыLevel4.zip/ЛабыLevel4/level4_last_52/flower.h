#ifndef FLOWER_H
#define FLOWER_H
#include <QPoint>
#include <QRect>

class Flower
{
public:
    Flower();

protected:
    QPoint pos;
    QRect size;
};

#endif // FLOWER_H

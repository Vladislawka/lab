#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QPainter>
#include <qDebug>
#include <QMouseEvent>
#include <QRect>
#include <QShortcut>
#include <QKeyEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    QImage grass(":/abc/grass16x16.GIF");
    QImage brick(":/abc/brick-tile-2.png");
    QImage tank(":/abc/t72.png");
    rotate.rotate(angle_rotate);
    tank = tank.transformed(rotate);
    painter.setBrush(grass);
    painter.drawRect(contentsRect());
    painter.setBrush(brick);
    if (flag_brick) {
        painter.drawRect(rect);
    }
    for (int i = 0; i < fig.size(); i++) {
        painter.drawRect(fig[i]);
    }
    painter.drawImage(rect_tank, tank);
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (event->modifiers() & Qt::ControlModifier) {
        flag_tank = 1;
        start = event->pos() - QPoint(100,100);
        finish = event->pos() + QPoint(100,100);
        rect_tank = QRect(start, finish);
        repaint();
    }
    else {
        flag_brick = 1;
        start = event->pos();
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if (flag_tank) {
        for (int i = 0; i < fig.size(); i++) {
            if (rect_tank.intersects(fig[i])) {
                flag_tank = 0;
            }
        }
    }
    if (flag_tank) {
        rect_tank.moveCenter(event->pos());
        repaint();
    }
    flag_tank = 1;
    if (flag_brick) {
        finish = event->pos();
        rect = QRect(start, finish);
        repaint();
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{

    if (flag_brick) {
        flag_brick = 0;
        fig.append(rect);
    }
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    for (int i = 0; i < fig.size(); i++) {
        if (rect_tank.intersects(fig[i])) {
            flag_tank = 0;
        }
    }
    if (flag_tank) {
        if (event->key() == Qt::Key_W) {
            rect_tank.moveCenter(rect_tank.center() + QPoint(0,-10));
            repaint();
        }
        if (event->key() == Qt::Key_A) {
            rotate.rotate(-90);
            rect_tank.moveCenter(rect_tank.center() + QPoint(-10,0));
            repaint();
            rotate.rotate(90);
        }
        if (event->key() == Qt::Key_S) {
            rotate.rotate(180);
            rect_tank.moveCenter(rect_tank.center() + QPoint(0,10));
            repaint();
            rotate.rotate(-180);
        }
        if (event->key() == Qt::Key_D) {
            rotate.rotate(90);
            rect_tank.moveCenter(rect_tank.center() + QPoint(10,0));
            repaint();
            rotate.rotate(-90);
        }
    }
}


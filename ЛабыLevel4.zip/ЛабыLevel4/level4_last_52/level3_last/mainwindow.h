#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QList>
#include <QRect>
#include <QShortcut>
#include <QTransform>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void keyPressEvent(QKeyEvent *event);

private:
    QTransform rotate;
    int angle_rotate = 0;
    QShortcut *KeyW;
    QList<QRect> fig;
    QRect rect;
    QRect rect_tank;
    QPoint start; QPoint finish;
    int flag_tank = 0;
    int flag_brick = 0;
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "tank.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class Tank;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void paintEvent(QPaintEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void keyPressEvent(QKeyEvent *event);

private:

    const QPoint brick_size{40,40};
    const QPoint flower_size{30,30};
    const QPoint tank_size{80,80};
    const int V = 10; // скорость танка

    QList<QRect> flowers;
    QList<QRect> bricks;

    Tank *tank = nullptr;

    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

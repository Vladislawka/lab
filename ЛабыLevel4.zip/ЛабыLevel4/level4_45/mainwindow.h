#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QList>
#include <QColor>
#include <QPainterPath>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT
class intersect;

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void paintEvent(QPaintEvent *event);
    void mousePressEvent(QMouseEvent *event);

private:
    const int R = 50;
    QList<QPoint> fig;

    const QList<QColor> colors = {
        QColor(255,255,255),//белый для фона
        QColor(255, 0, 0),// Красный
        QColor(255, 165, 0),// Оранжевый
        QColor(255, 255, 0),// Жёлтый
        QColor(0, 128, 0),// Зелёный
        QColor(0, 0, 255),// Синий
        QColor(128, 0, 128),// Фиолетовый
        QColor(255,192,203),// Розовый
    };
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

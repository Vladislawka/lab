#include "intersect.h"


intersect::intersect()
{

}

QList intersect::intersecting(QPainter *painter, QList arr)
{

}

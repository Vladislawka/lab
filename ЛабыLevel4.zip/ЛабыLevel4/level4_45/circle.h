#ifndef CIRCLE_H
#define CIRCLE_H
#include <QPoint>

class Circle
{
public:
    Circle();

protected:
    QPoint pos;
    int R;
};

#endif // CIRCLE_H

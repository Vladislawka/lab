#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QPainter>
#include <QRegion>
#include <QPainterPath>
#include <QMouseEvent>
#include <qDebug>
#include <QRect>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

int intersecting(QList<QPoint> arr, const int R, QPoint pixel)
{
    int count = 0;
    for (QPoint i: arr) if (sqrt(pow((i - pixel).rx(), 2) + pow((i - pixel).ry(), 2)) <= R) count ++;
    if (count == 0) return 0;
    if (count > 8) return 7;
    return count - 1;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    QRect rect = contentsRect();
    painter.setPen(QPen(QColor(255,255,255), 1));
    for (int i = 0; i < rect.width(); i++) {
        for (int j = 0; j < rect.height(); j++) {
            QPoint pixel{i,j};
            if (fig.size() > 0) painter.setPen(QPen(colors[intersecting(fig, R, pixel)]));
            painter.drawPoint(pixel);
        }
    }
    painter.setPen(QPen(QColor(0,0,0), Qt::SolidLine));
    for (QPoint i: fig) painter.drawEllipse(i, R, R);
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    fig.append(event->pos());
    repaint();
}


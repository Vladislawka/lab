#ifndef INTERSECT_H
#define INTERSECT_H
#include <QPainter>
#include <QList>

class intersect
{
public:
    intersect();
    QList interseting(QPainter *painter, QList arr);
};

#endif // INTERSECT_H

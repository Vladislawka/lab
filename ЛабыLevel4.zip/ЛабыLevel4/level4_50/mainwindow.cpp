#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QPainter>
#include <QMouseEvent>
#include <QPoint>
#include <QList>
#include <ranges>
#include <iostream>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


QPoint Center(QPoint point1, QPoint point2, QPoint point3)
{
    double x1 = point1.x(); double y1 = point1.y();
    double x2 = point2.x(); double y2 = point2.y();
    double x3 = point3.x(); double y3 = point3.y();

    double D = 2 * (x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2));

    if (D == 0) return QPoint();

    double X = ((x1*x1 + y1*y1) * (y2 - y3) +
                (x2*x2 + y2*y2) * (y3 - y1) +
                (x3*x3 + y3*y3) * (y1 - y2)) / D;

    double Y = ((x1*x1 + y1*y1) * (x3 - x2) +
                (x2*x2 + y2*y2) * (x1 - x3) +
                (x3*x3 + y3*y3) * (x2 - x1)) / D;

    return QPoint(X, Y);
}


void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    for (QPoint i: points) painter.drawEllipse(i,5,5);
    if (Rads.size() == 4){
        for (int i = 0; i < 4; i++) painter.drawEllipse(centers[i], static_cast<int>(Rads[i]),static_cast<int>(Rads[i]));
        // int dd = 0;
        // int maxs = 0;
        // for (int i = 0; i < Rads.size(); i++) {
        //     if (Rads[i] > maxs) {maxs = Rads[i], dd = i;}
        // }
        // painter.setPen(QPen(QColor(255,0,0,255),1));
        // painter.drawEllipse(centers[dd], Rads[dd],Rads[dd]);
    }
}
double Raduis(QPoint center, double max_R, QList<QPoint> points, double E)
{
    for (double R = 1; R < max_R; R+=E) {
        QList<double> check {
            abs(sqrt(pow((center - points[0]).rx(), 2) + pow((center - points[0]).ry(), 2)) - R),
            abs(sqrt(pow((center - points[1]).rx(), 2) + pow((center - points[1]).ry(), 2)) - R),
            abs(sqrt(pow((center - points[2]).rx(), 2) + pow((center - points[2]).ry(), 2)) - R),
            abs(sqrt(pow((center - points[3]).rx(), 2) + pow((center - points[3]).ry(), 2)) - R)
        };
        if (std::abs(std::accumulate(check.begin(), check.end(), 0) - 4*check[0]) < E) return R;
    }
    return 0;
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    points.append(event->pos());
    if (points.size() == 4) {
        QList<double> max_Rad;
        for (int i = 0; i < points.size(); i++) {
            for (int j = i+1; j < points.size(); j++) {
                for (int k = j+1; k < points.size(); k++) {
                    centers.append(Center(points[i], points[j], points[k]));
                }
            }
        }
        for (QPoint center: centers) {
            double max_R = 0;
            for (QPoint point: points) {
                double R = sqrt(pow((center - point).rx(), 2) + pow((center - point).ry(), 2));
                if (R > max_R) max_R = R;
            }
            max_Rad.append(max_R);
        }
        for (int i = 0; i < centers.size(); i++) {
            Rads.append(Raduis(centers[i], max_Rad[i], points, E));
        }
    }
    repaint();
}


#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void paintEvent(QPaintEvent *event);
    void mousePressEvent(QMouseEvent *event);

private:

    const int R = 50;
    QPoint sniper;
    QList<QPoint> baloons;

    double d = 0;
    bool flag_line = false;
    int flag_shot = 0;
    QLine line;
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

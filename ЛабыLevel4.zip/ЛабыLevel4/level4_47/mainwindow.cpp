#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QPainter>
#include <QMouseEvent>
#include <qDebug>
#include <QPoint>
#include <QList>
#include <QRect>
#include <QLine>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    QBrush sniper_color(QColor(68,160,80,240));
    for (int i = 0; i < baloons.size(); i++) {
        painter.drawEllipse(baloons[i], R, R);
    }
    if (flag_line) {
        painter.setBrush(sniper_color);
        painter.drawEllipse(sniper,10,10);
    }
}
double pointToLineDistance(const QPoint &point, const QLine &line) {
    double x0 = point.x();
    double y0 = point.y();
    double x1 = line.p1().x();
    double y1 = line.p1().y();
    double x2 = line.p2().x();
    double y2 = line.p2().y();

    // Формула расстояния от точки до прямой
    double numerator = abs((y2 - y1) * x0 - (x2 - x1) * y0 + x2 * y1 - y2 * x1);
    double denominator = sqrt((y2 - y1) * (y2 - y1) + (x2 - x1) * (x2 - x1));
    return numerator / denominator;
}

int count_ans(QList<int> arr, int count)
{
    // qDebug("%d", arr.size());
    for (int i: arr) if (i == count) return 1;
    if (std::accumulate(arr.begin(), arr.end(), 0) == count) return count;
    int shot = 0;
    int ans = 0;
    bool flag_count = false;
    for (int i = 0; i < arr.size(); i++) {
        if (arr[i] == 1 && !flag_count) {
            flag_count = true;
            continue;
        }
        else if (arr[i] == 1 && flag_count) {
            count -= shot;
            ans++;
            shot = 0;
            continue;
        }
        if (arr[i] != 1 && arr[i] > shot) shot = arr[i];
        if (count == 1) return ans + 1;
        // qDebug("%d %d %d",arr[i], ans, count);
    }
    return 1;
}
void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::RightButton) {
        flag_line = true;
        sniper = event->pos();
        QRect rect = contentsRect();
        int cur_for = 1;
        int ans = 0;
        int cur = 0;
        QList<int> count_shot;
        QList<QPoint> count_baloons;
        for (int i = 0; i < rect.width(); i++) {
            line = QLine{sniper,QPoint(i,0)};
            // Проводим все возможные выстрелы и считаем кол-во задетых шаров
            bool u;
            int count = 0;
            bool flag = false;
            for (QPoint baloon : baloons) {
                if (cur_for == 1) u = baloon.y() < sniper.y();
                if (cur_for == 2) u = baloon.x() > sniper.x();
                if (cur_for == 3) u = baloon.y() > sniper.y();
                if (cur_for == 4) u = baloon.x() < sniper.x();
                if (pointToLineDistance(baloon, line) < R && u) {
                    count++;
                    for (QPoint i: count_baloons) {
                        if (baloon == i) {
                            flag = true;
                            break;
                        }
                    }
                    if (!flag) count_baloons.append(baloon);
                    if (count_baloons.size() == 0) count_baloons.append(baloon);
                }
            }
            cur = count;
            if (count_shot.size() == 0 && cur > 0 || (count_shot.size() != 0 && count_shot[count_shot.size() - 1] != cur && cur != 0)) {
                count_shot.append(cur); // в список аппендим только новые значения
            }
            // for(int i: count_shot) qDebug("%d", i);
            if (count_shot.size() != 0 && cur == 0) { // как только вышел из блока шаров считаем наименьшее кол-во выстрелов
                ans += count_ans(count_shot, count_baloons.size());
                count_shot.clear();
                count_baloons.clear();
            }
        }
        // ans += count_ans(count_shot, count_baloons.size());
        cur_for++;
        for (int i = 0; i < rect.height(); i++) {
            line = QLine{sniper,QPoint(rect.width(),i)};
            // Проводим все возможные выстрелы и считаем кол-во задетых шаров
            bool u;
            int count = 0;
            bool flag = false;
            for (QPoint baloon : baloons) {
                if (cur_for == 1) u = baloon.y() < sniper.y();
                if (cur_for == 2) u = baloon.x() > sniper.x();
                if (cur_for == 3) u = baloon.y() > sniper.y();
                if (cur_for == 4) u = baloon.x() < sniper.x();
                if (pointToLineDistance(baloon, line) < R && u) {
                    count++;
                    for (QPoint i: count_baloons) {
                        if (baloon == i) {
                            flag = true;
                            break;
                        }
                    }
                    if (!flag) count_baloons.append(baloon);
                    if (count_baloons.size() == 0) count_baloons.append(baloon);
                }
            }
            cur = count;
            if (count_shot.size() == 0 && cur > 0 || (count_shot.size() != 0 && count_shot[count_shot.size() - 1] != cur && cur != 0)) {
                count_shot.append(cur); // в список аппендим только новые значения
            }
            // for(int i: count_shot) qDebug("%d", i);
            if (count_shot.size() != 0 && cur == 0) { // как только вышел из блока шаров считаем наименьшее кол-во выстрелов
                ans += count_ans(count_shot, count_baloons.size());
                count_shot.clear();
                count_baloons.clear();
            }
        }
        cur_for++;
        for (int i = rect.width(); i >= 0; i--) {
            line = QLine{sniper,QPoint(i,rect.height())};
            // Проводим все возможные выстрелы и считаем кол-во задетых шаров
            bool u;
            int count = 0;
            bool flag = false;
            for (QPoint baloon : baloons) {
                if (cur_for == 1) u = baloon.y() < sniper.y();
                if (cur_for == 2) u = baloon.x() > sniper.x();
                if (cur_for == 3) u = baloon.y() > sniper.y();
                if (cur_for == 4) u = baloon.x() < sniper.x();
                if (pointToLineDistance(baloon, line) <= R && u) {
                    count++;
                    for (QPoint i: count_baloons) {
                        if (baloon == i) {
                            flag = true;
                            break;
                        }
                    }
                    if (!flag) count_baloons.append(baloon);
                    if (count_baloons.size() == 0) count_baloons.append(baloon);
                }
            }
            cur = count;
            if (count_shot.size() == 0 && cur > 0 || (count_shot.size() != 0 && count_shot[count_shot.size() - 1] != cur && cur != 0)) {
                count_shot.append(cur); // в список аппендим только новые значения
            }
            // for(int i: count_shot) qDebug("%d", i);
            if (count_shot.size() != 0 && cur == 0) { // как только вышел из блока шаров считаем наименьшее кол-во выстрелов
                ans += count_ans(count_shot, count_baloons.size());
                count_shot.clear();
                count_baloons.clear();
            }
        }
        cur_for++;
        for (int i = rect.height(); i > 0; i--) {
            line = QLine{sniper,QPoint(0,i)};
            // Проводим все возможные выстрелы и считаем кол-во задетых шаров
            bool u;
            int count = 0;
            bool flag = false;
            for (QPoint baloon : baloons) {
                if (cur_for == 1) u = baloon.y() < sniper.y();
                if (cur_for == 2) u = baloon.x() > sniper.x();
                if (cur_for == 3) u = baloon.y() > sniper.y();
                if (cur_for == 4) u = baloon.x() < sniper.x();
                if (pointToLineDistance(baloon, line) < R && u) {
                    count++;
                    for (QPoint i: count_baloons) {
                        if (baloon == i) {
                            flag = true;
                            break;
                        }
                    }
                    if (!flag) count_baloons.append(baloon);
                    if (count_baloons.size() == 0) count_baloons.append(baloon);
                }
            }
            cur = count;
            if (count_shot.size() == 0 && cur > 0 || (count_shot.size() != 0 && count_shot[count_shot.size() - 1] != cur && cur != 0)) {
                count_shot.append(cur); // в список аппендим только новые значения
            }
            // for(int i: count_shot) qDebug("%d", i);
            if (count_shot.size() != 0 && cur == 0) { // как только вышел из блока шаров считаем наименьшее кол-во выстрелов
                ans += count_ans(count_shot, count_baloons.size());
                count_shot.clear();
                count_baloons.clear();
            }
        }
        ans += count_ans(count_shot, count_baloons.size()); // надо решить что делать с последней проверкой
        qDebug("%d", ans);
    }
    else {
        baloons.append(event->pos());
    }
    repaint();
}


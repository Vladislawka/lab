#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPoint>
#include <QLine>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void paintEvent(QPaintEvent *event);
    void mousePressEvent(QMouseEvent *event);

private:
    const int R1 = 50;
    const int R2 = 100;
    const int size_grid = 20;


    QLine trak;
    QList<QLine> trac;
    QList<QPoint> circle;
    QPoint ant{20*20,20*2};
    QPoint fly{20*13,20*23};
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QPainter>
#include <QList>
#include <QRect>
#include <qDebug>
#include <QMouseEvent>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::paintEvent(QPaintEvent *event)
{
    QBrush ant_color(QColor(255,0,10,255));
    QBrush fly_color(QColor(40,40,255,255));
    QBrush trak_color(QColor(255,0,0,255));
    QPen pen(QColor(255,0,0,255), Qt::DotLine);
    QPainter painter(this);
    QRect form = contentsRect();
    for (int x = 0; x < form.width(); x+=size_grid) {
        for (int y = 0; y < form.height(); y+=size_grid) {
            QRect rect{x,y,size_grid,size_grid};
            painter.drawRect(rect);
        }
    }
    for (int i = 0; i < circle.size(); i++) {
        if (i == 0) painter.drawEllipse(circle[i], R1, R1);
        if (i == 1) painter.drawEllipse(circle[i], R2, R2);
    }
    painter.setBrush(ant_color);
    painter.drawEllipse(ant, 5,5);
    painter.setBrush(fly_color);
    painter.drawEllipse(fly, 5,5);
    painter.setPen(pen);
    for (QLine line : trac) {
        painter.drawLine(line);
    }
}



void MainWindow::mousePressEvent(QMouseEvent *event)
{
    circle.append(event->pos());
    if (circle.size() == 2) {
        QList<int> moved;
        int past_move = -1;
        QList<int> check; // четвёрка как то, что все ходы доступны, остальные числа говорят какой ход нельзя сделать
        QList<QList<int>> unik{ // ходы на то, что он застрял
            {0,1,0},
            {1,0,1},
            {2,3,2},
            {3,2,3}
        };
        while (fly != ant) {
            bool flag = false;

            int num = 0;
            double min = 999999;

            QList<int> var_move;
            QList<QPoint> move {
                ant + QPoint(size_grid, 0),
                ant - QPoint(size_grid, 0),
                ant + QPoint(0,size_grid),
                ant - QPoint(0,size_grid),
            };
            QList<bool> usl {
                sqrt(pow((move[0] - circle[0]).rx(), 2) + pow((move[0] - circle[0]).ry(), 2)) > R1,
                sqrt(pow((move[0] - circle[1]).rx(), 2) + pow((move[0] - circle[1]).ry(), 2)) > R2,
                sqrt(pow((move[1] - circle[0]).rx(), 2) + pow((move[1] - circle[0]).ry(), 2)) > R1,
                sqrt(pow((move[1] - circle[1]).rx(), 2) + pow((move[1] - circle[1]).ry(), 2)) > R2,
                sqrt(pow((move[2] - circle[0]).rx(), 2) + pow((move[2] - circle[0]).ry(), 2)) > R1,
                sqrt(pow((move[2] - circle[1]).rx(), 2) + pow((move[2] - circle[1]).ry(), 2)) > R2,
                sqrt(pow((move[3] - circle[0]).rx(), 2) + pow((move[3] - circle[0]).ry(), 2)) > R1,
                sqrt(pow((move[3] - circle[1]).rx(), 2) + pow((move[3] - circle[1]).ry(), 2)) > R2,
            };
            for (int i = 0; i < move.size(); i++) {
                if (usl[2*i] && usl[2*i+1] && !check.contains(i)) {
                    var_move.append(i);
                }
            }
            for (int i: var_move) {
                if ((sqrt(pow((move[i] - fly).rx(), 2) + pow((move[i] - fly).ry(), 2)) < min)) {
                    min = sqrt(pow((move[i] - fly).rx(), 2) + pow((move[i] - fly).ry(), 2));
                    num = i;
                }
            }
            for (QList<int> i: unik) if (i == moved.mid(moved.size() - 3,3)) {
                // qDebug() << ant;
                for (int j = moved.mid(moved.size() - 3,3).size() - 1; j >= 0; j--) {
                    if (moved.mid(moved.size() - 3,3)[j] == 0) ant = ant - QPoint(size_grid,0);
                    if (moved.mid(moved.size() - 3,3)[j]  == 1) ant = ant + QPoint(size_grid,0);
                    if (moved.mid(moved.size() - 3,3)[j]  == 2) ant = ant - QPoint(0, size_grid);
                    if (moved.mid(moved.size() - 3,3)[j]  == 3) ant = ant + QPoint(0, size_grid);
                }
                // qDebug() << ant;
                // qDebug() << moved;
                // qDebug() << moved.mid(moved.size() - 3,3);
                check.append(moved.mid(moved.size() - 3,3).first());
                moved = moved.mid(0,moved.size()-3);
                // qDebug() << moved;
                qDebug() << check;
                QMessageBox::information(this, "ddd", "ddd");
                flag = true;
                break;
            }
            if (flag) continue;
            trac.append(QLine(ant,move[num]));
            ant = move[num];
            moved.append(num);
            past_move = num;
            check.clear();
            flag = false;
            repaint();
        }
    }
    repaint();
}


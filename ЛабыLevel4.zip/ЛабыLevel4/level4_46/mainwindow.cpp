#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QPainter>
#include <QMouseEvent>
#include <QPen>
#include <QDebug>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    const QBrush black(QColor(0,0,0,255));
    QString num = "10";
    QRect rect = contentsRect();

    center = QPoint(rect.width()/2,rect.height()/2);
    painter.drawText(center,num);

    for (int i = 1; i < 10; i++) {
        num = QString::number(10-i);
        painter.drawEllipse(center,i*R,i*R);
        painter.drawText(center - QPoint((R*(2*i+1))/2,0),num);
        painter.drawText(center - QPoint((-R*(2*i+1))/2,0),num);
        painter.drawText(center - QPoint(0,(R*(2*i+1))/2),num);
        painter.drawText(center - QPoint(0,(-R*(2*i+1))/2),num);
    }
    painter.drawEllipse(center,10*R,10*R);

    painter.setBrush(black);
    for (QPoint i: shots) painter.drawEllipse(i,5,5);
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    shots.append(event->pos());
    if (shots.size() == 5) {
        int score = 0;
        for (QPoint shot: shots) {
            double check = sqrt(pow((center - shot).rx(), 2) + pow((center - shot).ry(), 2));
            if (10 - std::floor(check/R) > 0) score += 10 - std::floor(check/R);
        }
        QMessageBox::information(this,"Результат",QString::number(score));
        shots.clear();
    }
    repaint();
}


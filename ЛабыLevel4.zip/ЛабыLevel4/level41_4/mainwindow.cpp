#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "circle.h"
#include <QPainter>
#include <QMouseEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QBrush brush;
    QRect rect = contentsRect();
    const int size_grid = 20;
    QPainter painter(this);
    if (ball) ball->draw(&painter);
    for (int x = 0; x < rect.width(); x += size_grid) {
        for (int y = 0; y < rect.height(); y += size_grid) {
            QRect grid{x,y,size_grid,size_grid};
            if (ball) {
                brush = ball->blue_grid(grid);
            }
            painter.setBrush(brush);
            painter.drawRect(grid);
        }
    }
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (!ball) {
        ball = new Circle(event->pos(), r);
    }
    repaint();
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if (ball) {
        ball = new Circle(event->pos(), r);
    }
    repaint();
}


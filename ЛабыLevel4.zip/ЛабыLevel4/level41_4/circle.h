#ifndef CIRCLE_H
#define CIRCLE_H
#include <QPoint>
#include <QPainter>

class Circle
{
public:
    Circle();
    Circle(QPoint pos, int R);

    void draw(QPainter *painter);
    QBrush blue_grid(const QRect rect);

protected:
    QPoint pos;
    int R;
};

#endif // CIRCLE_H

#include "circle.h"
#include <qmath.h>
#include <QPen>

Circle::Circle()
{

}

Circle::Circle(QPoint pos, int R)
    :pos(pos), R(R)
{

}

void Circle::draw(QPainter *painter)
{
    painter->drawEllipse(pos, R, R);
}

QBrush Circle::blue_grid(const QRect rect)
{
    const QBrush blue(QColor(0,0,255,255));
    const QBrush white(QColor(255,255,255,0));

    if (sqrt(pow((pos - rect.center()).rx(), 2) + pow((pos - rect.center()).ry(), 2)) > R) return white;
    QList<bool> check {
        sqrt(pow((pos - rect.topLeft()).rx(), 2) + pow((pos - rect.topLeft()).ry(), 2)) <= R,
        sqrt(pow((pos - rect.topRight()).rx(), 2) + pow((pos - rect.topRight()).ry(), 2)) <= R,
        sqrt(pow((pos - rect.bottomLeft()).rx(), 2) + pow((pos - rect.bottomLeft()).ry(), 2)) <= R,
        sqrt(pow((pos - rect.bottomRight()).rx(), 2) + pow((pos - rect.bottomRight()).ry(), 2)) <= R,
        };
    for (bool select: check) if (!select) return white;
    return blue;
}
